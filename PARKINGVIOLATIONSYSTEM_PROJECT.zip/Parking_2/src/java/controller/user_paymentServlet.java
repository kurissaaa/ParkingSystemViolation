package controller;

import dao.DAOUserPayment;
import model.Payment;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;

public class user_paymentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String payIDParam = request.getParameter("pay_ID");

        if (payIDParam != null && !payIDParam.isEmpty()) {
            try {
                int payID = Integer.parseInt(payIDParam);
                DAOUserPayment dao = new DAOUserPayment();
                Payment payment = dao.getPaymentById(payID);

                if (payment != null) {
                    request.setAttribute("payment", payment);
                    request.getRequestDispatcher("user_payment.jsp").forward(request, response);
                } else {
                    response.getWriter().write("Payment not found.");
                }

            } catch (NumberFormatException e) {
                response.getWriter().write("Invalid Payment ID.");
                e.printStackTrace();
            }
        } else {
            response.getWriter().write("Payment ID is required.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String payIDParam = request.getParameter("pay_ID");
        DAOUserPayment dao = new DAOUserPayment();
        boolean result = false;

        try {
            if (payIDParam != null && !payIDParam.isEmpty()) {
                int payID = Integer.parseInt(payIDParam);
                result = dao.updatePaymentStatusToPaid(payID);
            }

            if (result) {
                response.sendRedirect("user_paymentServlet?pay_ID=" + payIDParam);
            } else {
                response.getWriter().write("Failed to update payment.");
            }

        } catch (NumberFormatException e) {
            response.getWriter().write("Invalid Payment ID.");
            e.printStackTrace();
        } catch (Exception e) {
            response.getWriter().write("An error occurred during payment update.");
            e.printStackTrace();
        }
    }

    @Override
    public String getServletInfo() {
        return "Handles payment view and status update by user";
    }
}
