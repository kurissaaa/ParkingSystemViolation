package model;

public class Staff {
    private int staff_ID;
    private String staff_name;
    private String staff_IC;
    private String staff_contact;
    private String staff_password;

    public Staff(){
        
    }
    public Staff(int staff_ID, String staff_name, String staff_IC, String staff_contact, String staff_password) {
        this.staff_ID = staff_ID;
        this.staff_name = staff_name;
        this.staff_IC = staff_IC;
        this.staff_contact = staff_contact;
        this.staff_password = staff_password;
    }

    public int getStaff_ID() {
        return staff_ID;
    }

    public void setStaff_ID(int staff_ID) {
        this.staff_ID = staff_ID;
    }

    public String getStaff_name() {
        return staff_name;
    }

    public void setStaff_name(String staff_name) {
        this.staff_name = staff_name;
    }

    public String getStaff_IC() {
        return staff_IC;
    }

    public void setStaff_IC(String staff_IC) {
        this.staff_IC = staff_IC;
    }

    public String getStaff_contact() {
        return staff_contact;
    }

    public void setStaff_contact(String staff_contact) {
        this.staff_contact = staff_contact;
    }

    public String getStaff_password() {
        return staff_password;
    }

    public void setStaff_password(String staff_password) {
        this.staff_password = staff_password;
    }
}
