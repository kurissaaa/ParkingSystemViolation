package Connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
    public static Connection createConnection() {
        Connection con = null;
        String url = "jdbc:derby://localhost:1527/parking_2;create=true";
        String username = "parking";
        String password = "parking";

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver"); 
            con = DriverManager.getConnection(url, username, password);
            System.out.println("Printing Connection object: " + con);
        } catch (Exception e) {
            System.err.println("DB Connection Error:");
            e.printStackTrace();
        }

        return con;
    }
}
