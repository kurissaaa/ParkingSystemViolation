package dao;

import java.sql.*;
import Connection.DBConnection;
import model.Payment;

public class DAOUserPayment {
    public boolean updatePaymentStatusToPaid(int payID) {
        boolean updated = false;
        try (Connection conn = DBConnection.createConnection()) {
            String sql = "UPDATE PAYMENT SET PAY_STATUS = 'Paid' WHERE PAY_ID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, payID);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected != 0) {
                updated = true;
            }
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return updated;
    }

    public Payment getPaymentById(int payID) {
        Payment payment = null;

        try (Connection conn = DBConnection.createConnection()) {
            String sql = "SELECT * FROM PAYMENT WHERE PAY_ID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, payID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int vioID = rs.getInt("VIO_ID");
                double amount = rs.getDouble("PAY_AMOUNT");
                String date = rs.getString("PAY_DATE");
                String status = rs.getString("PAY_STATUS");

                payment = new Payment(payID, vioID, amount, date, status);
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return payment;
    }
    
    public void insertPaymentForViolation(int vioID, double amount, String date, String status) {
        try (Connection conn = DBConnection.createConnection()) {
            String sql = "INSERT INTO PAYMENT (VIO_ID, PAY_AMOUNT, PAY_DATE, PAY_STATUS) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, vioID);
            stmt.setDouble(2, amount);
            stmt.setString(3, date);
            stmt.setString(4, status);
            stmt.executeUpdate();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
