package controller;

import dao.DAOstudent;
import model.Student;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet({"/listStudent", "/insert", "/editStudent", "/delete"})
public class studentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DAOstudent dao;

    @Override
    public void init() {
        dao = new DAOstudent();
    }

    private void insertStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String stu_name = request.getParameter("stu_name");
        String stu_email = request.getParameter("stu_email");
        String stu_phone = request.getParameter("stu_phone");
        String stu_faculty = request.getParameter("stu_faculty");
        String password = request.getParameter("password");

        Student student = new Student(stu_name, stu_email, stu_phone, stu_faculty, password);
        dao.insertStudent(student);
        response.sendRedirect("listStudent");
    }

    private void editStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int stu_ID = Integer.parseInt(request.getParameter("stuID"));
        String stu_name = request.getParameter("stu_name");
        String stu_email = request.getParameter("stu_email");
        String stu_phone = request.getParameter("stu_phone");
        String stu_faculty = request.getParameter("stu_faculty");
        String password = request.getParameter("password");

        Student student = new Student(stu_ID,stu_name, stu_email, stu_phone, stu_faculty, password);
        dao.editStudent(student);
        response.sendRedirect("listStudent");
    }

    private void deleteStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int stu_ID = Integer.parseInt(request.getParameter("stuID"));
        dao.deleteStudent(stu_ID);
        response.sendRedirect("listStudent");
    }

    private void listStudent(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Student> listStudent = dao.selectAllStudent();
        System.out.println("Students fetched: " + listStudent.size()); // Debug log
        request.setAttribute("listStudent", listStudent);
        RequestDispatcher dispatcher = request.getRequestDispatcher("listStudent.jsp");
        dispatcher.forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int stu_ID = Integer.parseInt(request.getParameter("stuID"));
        Student student = dao.selectStudentById(stu_ID);
        request.setAttribute("student", student);
        RequestDispatcher dispatcher = request.getRequestDispatcher("editStudent.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();

        try {
            switch (action) {
                case "/insert":
                    insertStudent(request, response);
                    break;
                case "/editStudent":
                    showEditForm(request, response);
                    break;
                case "/delete":
                    deleteStudent(request, response);
                    break;
                case "/listStudent":
                default:
                    listStudent(request, response);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getServletPath();

        try {
            switch (action) {
                case "/insert":
                    insertStudent(request, response);
                    break;
                case "/editStudent":
                    editStudent(request, response);
                    break;
                default:
                    listStudent(request, response);
                    break;
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
