package dao;
import Connection.DBConnection;
import model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Tengku Maria
 */
public class DAOstudent {
    public DAOstudent() {
    }

    public void insertStudent(Student student) throws SQLException {
        String sql = "INSERT INTO Student (stu_name, stu_email, stu_phone, stu_faculty, password) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, student.getStu_Name());
            stmt.setString(2, student.getStu_Email());
            stmt.setString(3, student.getStu_Phone());
            stmt.setString(4, student.getStu_Faculty());
            stmt.setString(5, student.getPassword());
            stmt.executeUpdate();
        }
    }

    public boolean editStudent(Student student) throws SQLException {
        boolean rowUpdated;
        String sql = "UPDATE Student SET stu_name = ?, stu_email = ?, stu_phone = ?, stu_faculty = ?, password = ? WHERE stu_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, student.getStu_Name());
            stmt.setString(2, student.getStu_Email());
            stmt.setString(3, student.getStu_Phone());
            stmt.setString(4, student.getStu_Faculty());
            stmt.setString(5, student.getPassword());
            stmt.setInt(6, student.getStu_ID());

            rowUpdated = stmt.executeUpdate() > 0;
        }
        return rowUpdated;
    }

    public boolean deleteStudent(int stu_ID) throws SQLException {
        boolean rowDeleted;
        String sql = "DELETE FROM Student WHERE stu_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, stu_ID);
            rowDeleted = stmt.executeUpdate() > 0;
        }
        return rowDeleted;
    }

    public List<Student> selectAllStudent() throws SQLException {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM Student";

        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("stu_ID");
                String name = rs.getString("stu_name");
                String email = rs.getString("stu_email");
                String phone = rs.getString("stu_phone");
                String faculty = rs.getString("stu_faculty");
                String password = rs.getString("password");

                System.out.printf("Fetched Student: %d, %s, %s, %s, %s%n, %s",
                    id, name, email, phone, faculty, password);

                students.add(new Student(id, name, email, phone, faculty, password));
            }
        }
        return students;
    }
    
    public Student selectStudentById(int id) 
            throws SQLException {
        Student student = null;
        String sql = "SELECT * FROM Student WHERE stu_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                student = new Student(
                    rs.getInt("stu_ID"),
                    rs.getString("stu_name"),
                    rs.getString("stu_email"),
                    rs.getString("stu_phone"),
                    rs.getString("stu_faculty"),
                    rs.getString("password")
                );
            }
        }
        return student;
    }
}
