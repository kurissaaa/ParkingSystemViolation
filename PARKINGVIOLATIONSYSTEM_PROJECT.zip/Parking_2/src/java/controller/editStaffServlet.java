package controller;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import dao.DAOeditStaff;
import model.Staff;

@WebServlet("/editStaffServlet")
public class editStaffServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String idParam = request.getParameter("staffID");
        if (idParam == null || idParam.isEmpty()) {
            response.sendRedirect("StaffListServlet");
            return;
        }

        int staffID = Integer.parseInt(idParam);
        DAOeditStaff dao = new DAOeditStaff();

        try {
            Staff staff = dao.getStaffById(staffID);
            request.setAttribute("staff", staff);
            request.getRequestDispatcher("editStaff.jsp").forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int staffID = Integer.parseInt(request.getParameter("staff_ID"));
        String staffname = request.getParameter("staff_name");
        String staffIC = request.getParameter("staff_IC");
        String staffcontact = request.getParameter("staff_contact");
        String staffpassword = request.getParameter("staff_password");

        Staff staff = new Staff(staffID, staffname, staffIC, staffcontact, staffpassword);
        DAOeditStaff dao = new DAOeditStaff();

        try {
            dao.updateUser(staff);
        } catch (SQLException e) {
            throw new ServletException("Database error: " + e.getMessage());
        }

        response.sendRedirect("StaffListServlet");
    }
}
