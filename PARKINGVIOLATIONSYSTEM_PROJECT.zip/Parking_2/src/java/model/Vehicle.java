/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.io.Serializable;
import java.util.*;
/**
 *
 * @author Tengku Maria
 */
public class Vehicle implements Serializable{
    String veh_plate;
    int stu_ID;
    String veh_type;
    String veh_brand;
    String veh_color;
    
    public Vehicle(){
        
    }
    public Vehicle(String veh_plate, int stu_ID, String veh_type, String veh_brand, String veh_color){
        this.veh_plate = veh_plate;
        this.stu_ID = stu_ID;
        this.veh_type = veh_type;
        this.veh_brand = veh_brand;
        this.veh_color = veh_color;
    }
    
    public String getVeh_Plate(){
        return veh_plate;
    }
    public int getStu_ID(){
        return stu_ID;
    }
    public String getVeh_Type(){
        return veh_type;
    }
    public String getVeh_Brand(){
        return veh_brand;
    }
    public String getVeh_Color(){
        return veh_color;
    }
    
    public void setVeh_Plate(String veh_plate){
        this.veh_plate = veh_plate;
    }
    public void setStu_ID(int stu_ID){
        this.stu_ID=stu_ID;
    }
    public void setVeh_Type(String veh_type){
        this.veh_type = veh_type;
    }
    public void setVeh_Brand(String veh_brand){
        this.veh_brand = veh_brand;
    }
    public void setVeh_Color(String veh_color){
        this.veh_color = veh_color;
    }
}
