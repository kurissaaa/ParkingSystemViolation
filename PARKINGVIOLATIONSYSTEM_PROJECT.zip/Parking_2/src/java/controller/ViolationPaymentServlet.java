package controller;

import dao.DAOUserPayment;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/userViolationPay")
public class ViolationPaymentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String[] vioIDs = request.getParameterValues("vio_IDs");
        HttpSession session = request.getSession(false);
        String studentID = "Unknown";

        if (session != null) {
            Object obj = session.getAttribute("studentID");
            if (obj != null) {
                studentID = obj.toString();
            }
        }

        DAOUserPayment dao = new DAOUserPayment();
        double totalAmount = 0;
        String today = java.time.LocalDate.now().toString();

        if (vioIDs != null && vioIDs.length > 0) {
            for (int i = 0; i < vioIDs.length; i++) {
                try {
                    int vioID = Integer.parseInt(vioIDs[i]);
                    dao.insertPaymentForViolation(vioID, 100.0, today, "Paid");
                    totalAmount += 100;
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }
            }
            request.setAttribute("studentID", studentID);
            request.setAttribute("paymentDate", today);
            request.setAttribute("total", totalAmount);
            request.getRequestDispatcher("user_payment.jsp").forward(request, response);
        } else {
            response.getWriter().write("No violations selected!");
        }
    }
}
