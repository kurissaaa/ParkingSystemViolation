package test;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Connection.DBConnection;

public class TestPaymentQuery {
    public static void main(String[] args) {
        try (Connection conn = DBConnection.createConnection()) {
            if (conn == null) {
                System.out.println("Connection failed.");
                return;
            }

            String sql = "SELECT * FROM Payment";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            int count = 0;
            while (rs.next()) {
                System.out.println("Payment ID = " + rs.getInt("pay_ID"));
                count++;
            }

            if (count == 0) {
                System.out.println("No records found.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
