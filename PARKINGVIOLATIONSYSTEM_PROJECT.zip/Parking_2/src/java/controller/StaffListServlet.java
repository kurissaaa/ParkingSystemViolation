package controller;

import dao.DAOlistStaff;
import model.Staff;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import javax.servlet.annotation.WebServlet;

@WebServlet("/StaffListServlet")
public class StaffListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        DAOlistStaff dao = new DAOlistStaff();
        List<Staff> staffList = dao.getAllStaff();

        request.setAttribute("staffList", staffList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("list_Staff.jsp");
        dispatcher.forward(request, response);
    }
}
