package dao;
import Connection.DBConnection;
import model.Violation;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOViolation {

    public void insertViolation(Violation violation) throws SQLException {
        String sql = "INSERT INTO Violation (veh_plate, Staff_ID, vio_date, vio_location, vio_type) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, violation.getVeh_Plate());
            stmt.setInt(2, violation.getStaff_ID());
            stmt.setString(3, violation.getVio_Date());
            stmt.setString(4, violation.getVio_Location());
            stmt.setString(5, violation.getVio_Type());

            stmt.executeUpdate();
        }
    }

    public boolean editViolation(Violation violation) throws SQLException {
        String sql = "UPDATE Violation SET veh_plate = ?, Staff_ID = ?, vio_date = ?, vio_location = ?, vio_type = ? WHERE vio_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, violation.getVeh_Plate());
            stmt.setInt(2, violation.getStaff_ID());
            stmt.setString(3, violation.getVio_Date());
            stmt.setString(4, violation.getVio_Location());
            stmt.setString(5, violation.getVio_Type());
            stmt.setInt(6, violation.getVio_ID());

            return stmt.executeUpdate() > 0;
        }
    }

    public boolean deleteViolation(int vio_ID) throws SQLException {
        String sql = "DELETE FROM Violation WHERE vio_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, vio_ID);
            return stmt.executeUpdate() > 0;
        }
    }

    public List<Violation> selectAllViolations() throws SQLException {
        List<Violation> violations = new ArrayList<>();
        String sql = "SELECT * FROM Violation";

        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Violation v = new Violation(
                        rs.getInt("vio_ID"),
                        rs.getString("veh_plate"),
                        rs.getInt("Staff_ID"),
                        rs.getString("vio_date"),
                        rs.getString("vio_location"),
                        rs.getString("vio_type")
                );
                violations.add(v);
            }
        }
        return violations;
    }

    public Violation selectViolationById(int vio_ID) throws SQLException {
        String sql = "SELECT * FROM Violation WHERE vio_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, vio_ID);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Violation(
                        rs.getInt("vio_ID"),
                        rs.getString("veh_plate"),
                        rs.getInt("Staff_ID"),
                        rs.getString("vio_date"),
                        rs.getString("vio_location"),
                        rs.getString("vio_type")
                );
            }
        }
        return null;
    }

    public List<Violation> selectViolationsByPlate(String plateNum) throws SQLException {
        List<Violation> list = new ArrayList<>();

        String sql =
            "SELECT * FROM Violation " + "WHERE veh_plate = ? " +
            "AND vio_ID NOT IN (SELECT vio_ID FROM Payment WHERE pay_status = 'Paid') " +
            "ORDER BY vio_date DESC";

        try (Connection conn = DBConnection.createConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, plateNum);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Violation vio = new Violation();
                vio.setVio_ID(rs.getInt("vio_ID"));
                vio.setVeh_Plate(rs.getString("veh_plate"));
                vio.setVio_Date(rs.getString("vio_date"));
                vio.setVio_Location(rs.getString("vio_location"));
                vio.setVio_Type(rs.getString("vio_type"));
                list.add(vio);
            }
        }

        return list;
    }
}
