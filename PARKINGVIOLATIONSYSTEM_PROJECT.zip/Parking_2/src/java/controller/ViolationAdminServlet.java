package controller;

import dao.DAOViolation;
import model.Violation;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.annotation.WebServlet;

@WebServlet("/ViolationAdminServlet")
public class ViolationAdminServlet extends HttpServlet {
    private DAOViolation dao;

    @Override
    public void init() {
        dao = new DAOViolation();
    }

    private void insertViolation(HttpServletRequest request, HttpServletResponse response)
        throws SQLException, IOException, ServletException {

        String veh_plate = request.getParameter("veh_plate");
        Integer staffID = (Integer) request.getSession().getAttribute("staffID");
        if (staffID == null || staffID <= 0) {
            request.setAttribute("error", "Session expired or invalid. Please log in again.");
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
            return;
        }

        String vio_date = request.getParameter("vio_date");
        String vio_location = request.getParameter("vio_location");
        String vio_type = request.getParameter("vio_type");

        Violation violation = new Violation(veh_plate, staffID, vio_date, vio_location, vio_type);
        dao.insertViolation(violation);
        response.sendRedirect("ViolationAdminServlet?action=list");
    }

    private void editViolation(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int vio_ID = Integer.parseInt(request.getParameter("vio_ID"));
        String veh_plate = request.getParameter("veh_plate");
        int Staff_ID = Integer.parseInt(request.getParameter("Staff_ID"));
        String vio_date = request.getParameter("vio_date");
        String vio_location = request.getParameter("vio_location");
        String vio_type = request.getParameter("vio_type");

        Violation violation = new Violation(vio_ID, veh_plate, Staff_ID, vio_date, vio_location, vio_type);
        dao.editViolation(violation);
        response.sendRedirect("ViolationAdminServlet?action=list");
    }

    private void deleteViolation(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int vio_ID = Integer.parseInt(request.getParameter("vio_ID"));
        dao.deleteViolation(vio_ID);
        response.sendRedirect("ViolationAdminServlet?action=list");
    }

    private void listViolations(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException, ServletException {
        List<Violation> list = dao.selectAllViolations();
        request.getSession().setAttribute("violations", list);
        response.sendRedirect("list_violation.jsp");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int vio_ID = Integer.parseInt(request.getParameter("vio_ID"));
        Violation violation = dao.selectViolationById(vio_ID);
        request.setAttribute("violation", violation);
        RequestDispatcher dispatcher = request.getRequestDispatcher("editViolation.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action == null || action.equals("list")) {
                listViolations(request, response);
            } else if (action.equals("edit")) {
                showEditForm(request, response);
            } else if (action.equals("delete")) {
                deleteViolation(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        try {
            if (action.equals("insert")) {
                insertViolation(request, response);
            } else if (action.equals("edit")) {
                editViolation(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
