package controller;

import dao.DAOVehicle;
import model.Vehicle;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/adminVehicle")
public class AdminVehicleServlet extends HttpServlet {
    private DAOVehicle vehicleDAO;

    public void init() {
        vehicleDAO = new DAOVehicle();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        if (action == null) 
            action = "list"; 

        switch (action) {
            case "createForm":
                showCreateForm(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "view":
                showVehicleInfo(request, response);
                break;
            case "delete":
                deleteVehicle(request, response);
                break;
            case "list":
            default:
                listVehicles(request, response);
                break;
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        switch (action) {
            case "create":
                createVehicle(request, response);
                break;
            case "update":
                updateVehicle(request, response);
                break;
            case "delete":
                deleteVehicle(request, response);
                break;
            default:
                response.sendRedirect("adminVehicle?action=list");
        }
    }

    private void listVehicles(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Vehicle> vehicleList = vehicleDAO.getAllVehicles();
        request.setAttribute("vehicleList", vehicleList);
        RequestDispatcher dispatcher = request.getRequestDispatcher("list_vehicle.jsp");
        dispatcher.forward(request, response);
    }

    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("vehicle_form.jsp");
        dispatcher.forward(request, response);
    }

    private void createVehicle(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String veh_plate = request.getParameter("veh_plate");
        int stu_ID = Integer.parseInt(request.getParameter("stu_ID"));
        String veh_type = request.getParameter("veh_type");
        String veh_brand = request.getParameter("veh_brand");
        String veh_color = request.getParameter("veh_color");

        Vehicle vehicle = new Vehicle(veh_plate, stu_ID, veh_type, veh_brand, veh_color);
        vehicleDAO.insertVehicle(vehicle);
        response.sendRedirect("adminVehicle?action=list");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String veh_plate = request.getParameter("veh_plate");
        Vehicle vehicle = vehicleDAO.getVehicleByPlate(veh_plate);
        request.setAttribute("vehicle", vehicle);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Vehicle_update.jsp");
        dispatcher.forward(request, response);
    }

    private void updateVehicle(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String veh_plate = request.getParameter("veh_plate");
        int stu_ID = Integer.parseInt(request.getParameter("stu_ID"));
        String veh_type = request.getParameter("veh_type");
        String veh_brand = request.getParameter("veh_brand");
        String veh_color = request.getParameter("veh_color");

        Vehicle updatedVehicle = new Vehicle(veh_plate, stu_ID, veh_type, veh_brand, veh_color);
        vehicleDAO.updateVehicle(updatedVehicle);
        response.sendRedirect("adminVehicle?action=list");
    }

    private void deleteVehicle(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String veh_plate = request.getParameter("veh_plate");
        vehicleDAO.deleteVehicle(veh_plate);
        response.sendRedirect("adminVehicle?action=list");
    }

    private void showVehicleInfo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String veh_plate = request.getParameter("veh_plate");
        Vehicle vehicle = vehicleDAO.getVehicleByPlate(veh_plate);
        request.setAttribute("vehicle", vehicle);
        RequestDispatcher dispatcher = request.getRequestDispatcher("Vehicle_info.jsp");
        dispatcher.forward(request, response);
    }
}
