package controller;

import model.Staff;
import dao.DAOcreateStaff;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/createStaffServlet")
public class createStaffServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String staffPassword = request.getParameter("Staff_password");
        String staffIc = request.getParameter("Staff_IC");
        String staffName = request.getParameter("Staff_name");
        String staffContact = request.getParameter("Staff_contact");


        Staff staff = new Staff();
        staff.setStaff_password(staffPassword);
        staff.setStaff_IC(staffIc);
        staff.setStaff_name(staffName);
        staff.setStaff_contact(staffContact);

        DAOcreateStaff dao = new DAOcreateStaff();
        String result = dao.registerUser(staff);

        if (result.equals("SUCCESS")) {
            HttpSession session = request.getSession();
            session.setAttribute("staffID", staff.getStaff_ID());
            response.sendRedirect("StaffListServlet");
        } else {
            request.setAttribute("errorMessage", result);
            request.getRequestDispatcher("createStaff.jsp").forward(request, response);
        }   
        System.out.println("Staff Insert Result: " + result);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        doPost(request, response);
    }
}
