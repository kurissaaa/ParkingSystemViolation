package dao;
import model.Staff;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import Connection.DBConnection;
/**
 *
 * @author Tengku Maria
 */
public class DAOcreateStaff {

    public String registerUser(Staff staff) {
        Connection conn = null;
        PreparedStatement stmt = null;

        String staffPassword = staff.getStaff_password();
        String staffIc = staff.getStaff_IC();
        String staffName = staff.getStaff_name();
        String staffContact = staff.getStaff_contact();

        try {
            conn = DBConnection.createConnection();

            if (conn == null) {
                return "Database connection failed!";
            }

            String sql = "INSERT INTO Staff (Staff_password, Staff_IC, Staff_name, Staff_contact) VALUES (?, ?, ?, ?)";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, staffPassword);
            stmt.setString(2, staffIc);
            stmt.setString(3, staffName);
            stmt.setString(4, staffContact);

            int i = stmt.executeUpdate();

            if (i > 0) {
                return "SUCCESS";
            } else {
                return "FAIL";
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return "Error: " + e.getMessage();
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}
