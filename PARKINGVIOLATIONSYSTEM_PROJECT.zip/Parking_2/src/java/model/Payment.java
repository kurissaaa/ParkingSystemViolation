/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.io.Serializable;
import java.util.*;
/**
 *
 * @author Tengku Maria
 */
public class Payment implements Serializable{
    int pay_ID;
    int vio_ID;
    double pay_amount;
    String pay_date;
    String pay_status;
    
    public Payment(){
    }
    public Payment(int pay_ID, int vio_ID, double pay_amount, String pay_date, String pay_status){
        this.pay_ID = pay_ID;
        this.vio_ID = vio_ID;
        this.pay_amount = pay_amount;
        this.pay_date = pay_date;
        this.pay_status = pay_status;
    }
    
    public int getPay_ID(){
        return pay_ID;
    }
    public int getVio_ID(){
        return vio_ID;
    }
    public double getPay_Amount(){
        return pay_amount;
    }
    public String getPay_Date(){
        return pay_date;
    }
    public String getPay_Status(){
        return pay_status;
    }
    
    public void setPay_ID(int pay_ID){
        this.pay_ID =pay_ID;
    }
    public void setVio_ID(int vio_ID){
        this.vio_ID =vio_ID;
    }
    public void setPay_Amount(double pay_amount){
        this.pay_amount =pay_amount;
    }
    public void setPay_Date(String pay_date){
        this.pay_date =pay_date;
    }
    public void setPay_Status(String pay_status){
        this.pay_status =pay_status;
    }
}
