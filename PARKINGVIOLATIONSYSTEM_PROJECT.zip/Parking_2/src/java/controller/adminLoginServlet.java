package controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import dao.DAOadminLogin;
import javax.servlet.annotation.WebServlet;
/**
 *
 * @author Tengku Maria
 */
@WebServlet("/adminLoginServlet")
public class adminLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        int staffID = Integer.parseInt(request.getParameter("Staff_ID"));
        String staffPassword = request.getParameter("Staff_password");

        DAOadminLogin dao = new DAOadminLogin();
        boolean result = dao.login(staffID, staffPassword);

        if (result) {
            HttpSession session = request.getSession();
            session.setAttribute("staffID", staffID);
            response.sendRedirect("dashboardAdmin.jsp");
        } else {
            request.setAttribute("errorMessage", "Invalid ID or password!");
            request.getRequestDispatcher("adminLogin.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("adminLogin.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Handles admin login functionality";
    }
}