package dao;

import Connection.DBConnection;
import model.Payment;
import java.sql.*;
import java.util.*;

public class DAOListPayment {
    public List<Payment> getAllPayment() {
        List<Payment> paymentList = new ArrayList<>();
        try (Connection conn = DBConnection.createConnection()) {
            String sql = "SELECT pay_ID, vio_ID, pay_amount, pay_date, pay_status FROM Payment";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Payment payment = new Payment();
                payment.setPay_ID(rs.getInt("pay_ID"));
                payment.setVio_ID(rs.getInt("vio_ID"));
                payment.setPay_Amount(rs.getDouble("pay_amount"));
                payment.setPay_Date(rs.getString("pay_date"));
                payment.setPay_Status(rs.getString("pay_status"));
                paymentList.add(payment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return paymentList;
    }

    public void updatePayment(int payID, double amount, String status) {
        try (Connection conn = DBConnection.createConnection()) {
            String sql = "UPDATE Payment SET pay_amount = ?, pay_status = ? WHERE pay_ID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDouble(1, amount);
            stmt.setString(2, status);
            stmt.setInt(3, payID);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Payment getPaymentById(int payID) {
        Payment payment = null;
        try (Connection conn = DBConnection.createConnection()) {
            String sql = "SELECT * FROM Payment WHERE pay_ID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, payID);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                payment = new Payment(
                    rs.getInt("pay_ID"),
                    rs.getInt("vio_ID"),
                    rs.getDouble("pay_amount"),
                    rs.getString("pay_date"),
                    rs.getString("pay_status")
                );
            }
            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return payment;
    }
}
