package controller;

import dao.DAOListPayment;
import model.Payment;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.util.List;

@WebServlet("/listPayment")
public class admin_paymentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        DAOListPayment dao = new DAOListPayment();

        try {
            if ("edit".equals(action)) {
                int payID = Integer.parseInt(request.getParameter("pay_ID"));
                Payment payment = dao.getPaymentById(payID);

                if (payment != null) {
                    request.setAttribute("payment", payment);
                    request.getRequestDispatcher("edit_payment.jsp").forward(request, response);
                } else {
                    request.setAttribute("errorMessage", "Payment not found.");
                    request.getRequestDispatcher("list_payment.jsp").forward(request, response);
                }

            } else if ("info".equals(action)) {
                int payID = Integer.parseInt(request.getParameter("pay_ID"));
                Payment payment = dao.getPaymentById(payID);

                if (payment != null) {
                    request.setAttribute("payment", payment);
                    request.getRequestDispatcher("payment_info.jsp").forward(request, response);
                } else {
                    request.setAttribute("errorMessage", "Payment not found.");
                    request.getRequestDispatcher("list_payment.jsp").forward(request, response);
                }

            } else if (request.getParameter("searchPayID") != null) {
                try {
                    int payID = Integer.parseInt(request.getParameter("searchPayID"));
                    Payment payment = dao.getPaymentById(payID);

                    if (payment != null) {
                        request.setAttribute("searchedPayment", payment);
                    } else {
                        request.setAttribute("searchMessage", "No payment found for ID: " + payID);
                    }

                } catch (NumberFormatException e) {
                    request.setAttribute("searchMessage", "Invalid payment ID format.");
                }

                request.getRequestDispatcher("list_payment.jsp").forward(request, response);

            } else {
                List<Payment> list_payment = dao.getAllPayment();
                request.setAttribute("list_payment", list_payment);
                request.getRequestDispatcher("list_payment.jsp").forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "An error occurred while processing your request.");
            request.getRequestDispatcher("list_payment.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        DAOListPayment dao = new DAOListPayment();

        try {
            if ("update".equals(action)) {
                int payID = Integer.parseInt(request.getParameter("pay_ID"));
                double amount = Double.parseDouble(request.getParameter("pay_amount"));
                String status = request.getParameter("pay_status");

                dao.updatePayment(payID, amount, status);
                request.setAttribute("successMessage", "Payment updated successfully.");
                response.sendRedirect("listPayment");

            } else {
                doGet(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Failed to update payment.");
            request.getRequestDispatcher("list_payment.jsp").forward(request, response);
        }
    }
}
