package dao;

import Connection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import model.Staff;
/**
 *
 * @author Tengku Maria
 */
public class DAOeditStaff {
    public boolean updateUser(Staff staff) throws SQLException {
        boolean rowUpdated;
        try (Connection conn = DBConnection.createConnection()) {
            String sql = "UPDATE Staff SET Staff_name = ?, Staff_IC = ?, Staff_contact=?, Staff_password=? WHERE Staff_ID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, staff.getStaff_name());
            stmt.setString(2, staff.getStaff_IC());
            stmt.setString(3, staff.getStaff_contact());
            stmt.setString(4, staff.getStaff_password());
            stmt.setInt(5, staff.getStaff_ID());

            rowUpdated = stmt.executeUpdate() > 0;
        }
        return rowUpdated;
    }
    
    public Staff getStaffById(int id) throws SQLException {
        Staff staff = null;
        try (Connection conn = DBConnection.createConnection()) {
            String sql = "SELECT * FROM Staff WHERE Staff_ID = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                staff = new Staff();
                staff.setStaff_ID(rs.getInt("Staff_ID"));
                staff.setStaff_name(rs.getString("Staff_name"));
                staff.setStaff_IC(rs.getString("Staff_IC"));
                staff.setStaff_contact(rs.getString("Staff_contact"));
                staff.setStaff_password(rs.getString("Staff_password"));
            }
        }
        return staff;
    }
}
