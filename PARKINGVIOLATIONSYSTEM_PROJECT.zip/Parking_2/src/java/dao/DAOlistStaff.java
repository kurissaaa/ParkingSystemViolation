package dao;
import Connection.DBConnection;
import model.Staff;
import java.sql.*;
import java.util.*;
/**
 *
 * @author Tengku Maria
 */
public class DAOlistStaff {
    public List<Staff> getAllStaff(){
        List<Staff> staffList = new ArrayList<>();
        
        try{
            Connection conn = DBConnection.createConnection();
            String sql = "SELECT Staff_ID, Staff_name, Staff_IC, Staff_contact, Staff_password FROM Staff";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            while(rs.next()){
                Staff staff = new Staff();
                staff.setStaff_ID(rs.getInt("Staff_ID"));
                staff.setStaff_name(rs.getString("Staff_name"));
                staff.setStaff_IC(rs.getString("Staff_IC"));
                staff.setStaff_contact(rs.getString("Staff_contact"));
                staff.setStaff_password(rs.getString("Staff_password"));
                staffList.add(staff);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return staffList;
    }
}
