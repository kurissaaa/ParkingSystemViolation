package dao;

import Connection.DBConnection;
import java.sql.*;
import java.util.*;
import model.Student;

/**
 *
 * @author Tengku Maria
 */
public class DAOstudentUser {
    public boolean login(int studentID, String password){
        try{
            Connection conn = DBConnection.createConnection();
            String sql = "SELECT * FROM Student WHERE stu_ID = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentID);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
    
    public Student selectStudentById(int id) 
            throws SQLException {
        Student student = null;
        String sql = "SELECT * FROM Student WHERE stu_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                student = new Student(
                    rs.getInt("stu_ID"),
                    rs.getString("stu_name"),
                    rs.getString("stu_email"),
                    rs.getString("stu_phone"),
                    rs.getString("stu_faculty"),
                    rs.getString("password")
                );
            }
        }
        return student;
    }
    
    public List<String> getVehiclePlatesByStudentID(int studentID) throws SQLException {
        List<String> plates = new ArrayList<>();
        String sql = "SELECT veh_plate FROM Vehicle WHERE stu_ID = ?";
        try (Connection conn = DBConnection.createConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                plates.add(rs.getString("veh_plate"));
            }
        }
        return plates;
    }
    
    public int registerStudent(Student student) throws SQLException {
        String insertSQL = "INSERT INTO Student (stu_name, stu_email, stu_phone, stu_faculty, password) VALUES (?, ?, ?, ?, ?)";
        String selectSQL = "SELECT stu_ID FROM Student WHERE stu_email = ?";

        try (Connection conn = DBConnection.createConnection()) {
            try (PreparedStatement stmt = conn.prepareStatement(insertSQL)) {
                stmt.setString(1, student.getStu_Name());
                stmt.setString(2, student.getStu_Email());
                stmt.setString(3, student.getStu_Phone());
                stmt.setString(4, student.getStu_Faculty());
                stmt.setString(5, student.getPassword());
                stmt.executeUpdate();
            }
            try (PreparedStatement stmt = conn.prepareStatement(selectSQL)) {
                stmt.setString(1, student.getStu_Email());
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt("stu_ID");
                }
            }
        }
        return -1;
    }
    
}
