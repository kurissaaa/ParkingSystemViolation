/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.io.Serializable;
import java.util.*;
/**
 *
 * @author Tengku Maria
 */
public class Violation implements Serializable{
    int vio_ID;
    String veh_plate;
    int Staff_ID;
    String vio_date;
    String vio_location;
    String vio_type;
    
    public Violation(){
        
    }
    public Violation(int vio_ID, String veh_plate, int Staff_ID, String vio_date, String vio_location, String vio_type){
        this.vio_ID = vio_ID;
        this.veh_plate = veh_plate;
        this.Staff_ID = Staff_ID;
        this.vio_date = vio_date;
        this.vio_location = vio_location;
        this.vio_type = vio_type;
    }
    public Violation(String veh_plate, int Staff_ID, String vio_date, String vio_location, String vio_type){
        this.veh_plate = veh_plate;
        this.Staff_ID = Staff_ID;
        this.vio_date = vio_date;
        this.vio_location = vio_location;
        this.vio_type = vio_type;
    }
    
    
    public int getVio_ID(){
        return vio_ID;
    }
    public String getVeh_Plate(){
        return veh_plate;
    }
    public int getStaff_ID(){
        return Staff_ID;
    }
    public String getVio_Date(){
        return vio_date;
    }
    public String getVio_Location(){
        return vio_location;
    }
    public String getVio_Type(){
        return vio_type;
    }
    
    public void setVio_ID(int vio_ID){
        this.vio_ID = vio_ID;
    }
    public void setVeh_Plate(String veh_plate){
        this.veh_plate = veh_plate;
    }
    public void setStaff_ID(int Staff_ID){
        this.Staff_ID = Staff_ID;
    }
    public void setVio_Date(String vio_date){
        this.vio_date = vio_date;
    }
    public void setVio_Location(String vio_location){
        this.vio_location = vio_location;
    }
    public void setVio_Type(String vio_type){
        this.vio_type = vio_type;
    }
}
    
