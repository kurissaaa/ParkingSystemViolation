/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.io.Serializable;
import java.util.*;
/**
 *
 * @author Tengku Maria
 */
public class Student implements Serializable{
    int stu_ID;
    String stu_name;
    String stu_email;
    String stu_phone;
    String stu_faculty;
    String password;
    
    public Student(){
        
    }
    public Student(int stu_ID, String stu_name, String stu_email, String stu_phone, String stu_faculty, String password){
        this.stu_ID=stu_ID;
        this.stu_email=stu_email;
        this.stu_faculty=stu_faculty;
        this.stu_name=stu_name;
        this.stu_phone=stu_phone;
        this.password = password;
    }

    public Student(String stu_name, String stu_email, String stu_phone, String stu_faculty, String password) {
        this.stu_email=stu_email;
        this.stu_faculty=stu_faculty;
        this.stu_name=stu_name;
        this.stu_phone=stu_phone; 
        this.password = password;
    }
    
    public int getStu_ID(){
        return stu_ID;
    }
    public String getStu_Name(){
        return stu_name;
    }
    public String getStu_Email(){
        return stu_email;
    }
    public String getStu_Phone(){
        return stu_phone;
    }
    public String getStu_Faculty(){
        return stu_faculty;
    }
    public String getPassword(){
        return password;
    }
    
    public void setStu_ID(int stu_ID){
        this.stu_ID=stu_ID;
    }
    public void setStu_Name(String stu_name){
        this.stu_name=stu_name;
    }
    public void setStu_Email(String stu_email){
        this.stu_email=stu_email;
    }
    public void setStu_Phone(String stu_phone){
        this.stu_phone=stu_phone;
    }
    public void setStu_Faculty(String stu_faculty){
        this.stu_faculty=stu_faculty;
    }
    public void setPassword(String password){
        this.password = password;
    }
}
