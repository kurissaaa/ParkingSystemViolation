package dao;
import Connection.DBConnection;
import model.Vehicle;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOVehicle {
    protected Connection getConnection() 
        throws SQLException {
        return DBConnection.createConnection();
    }

    public void insertVehicle(Vehicle vehicle) {
        String sql = "INSERT INTO Vehicle (veh_plate, stu_ID, veh_type, veh_brand, veh_color) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, vehicle.getVeh_Plate());
            stmt.setInt(2, vehicle.getStu_ID());
            stmt.setString(3, vehicle.getVeh_Type());
            stmt.setString(4, vehicle.getVeh_Brand());
            stmt.setString(5, vehicle.getVeh_Color());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Vehicle> getAllVehicles() {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM Vehicle";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                vehicles.add(new Vehicle(
                        rs.getString("veh_plate"),
                        rs.getInt("stu_ID"),
                        rs.getString("veh_type"),
                        rs.getString("veh_brand"),
                        rs.getString("veh_color")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vehicles;
    }

    public List<Vehicle> getVehiclesByStudentId(int studentId) {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM Vehicle WHERE stu_ID = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                vehicles.add(new Vehicle(
                        rs.getString("veh_plate"),
                        rs.getInt("stu_ID"),
                        rs.getString("veh_type"),
                        rs.getString("veh_brand"),
                        rs.getString("veh_color")
                ));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vehicles;
    }

    public Vehicle getVehicleByPlate(String plate) {
        Vehicle vehicle = null;
        String sql = "SELECT * FROM Vehicle WHERE veh_plate = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, plate);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                vehicle = new Vehicle(
                        rs.getString("veh_plate"),
                        rs.getInt("stu_ID"),
                        rs.getString("veh_type"),
                        rs.getString("veh_brand"),
                        rs.getString("veh_color")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return vehicle;
    }

    public void updateVehicle(Vehicle vehicle) {
        String sql = "UPDATE Vehicle SET stu_ID = ?, veh_type = ?, veh_brand = ?, veh_color = ? WHERE veh_plate = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, vehicle.getStu_ID());
            stmt.setString(2, vehicle.getVeh_Type());
            stmt.setString(3, vehicle.getVeh_Brand());
            stmt.setString(4, vehicle.getVeh_Color());
            stmt.setString(5, vehicle.getVeh_Plate());

            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteVehicle(String plate) {
        String sql = "DELETE FROM Vehicle WHERE veh_plate = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, plate);
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean deleteVehicleByPlateAndStudent(String plate, int studentId) {
        String sql = "DELETE FROM Vehicle WHERE veh_plate = ? AND stu_ID = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, plate);
            stmt.setInt(2, studentId);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
}
