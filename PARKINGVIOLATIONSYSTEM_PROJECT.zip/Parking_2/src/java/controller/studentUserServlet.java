package controller;

import dao.DAOstudentUser;
import model.Student;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/studentLogin")
public class studentUserServlet extends HttpServlet {

    protected void login(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int studentID = Integer.parseInt(request.getParameter("stu_ID"));
        String password = request.getParameter("password");

        DAOstudentUser dao = new DAOstudentUser();
        boolean result = dao.login(studentID, password);

        if (result) {
            try {
                Student student = dao.selectStudentById(studentID);
                List<Student> list = new ArrayList<>();
                list.add(student);

                HttpSession session = request.getSession();
                session.setAttribute("studentID", studentID);
                session.setAttribute("listStudent", list);

                List<String> plates = dao.getVehiclePlatesByStudentID(studentID);
                System.out.println("veh_plate list added to session: " + plates);
                session.setAttribute("veh_plate", plates);

                response.sendRedirect("studentDisplay.jsp");
            } catch (SQLException e) {
                throw new ServletException("Database error fetching student info", e);
            }
        } else {
            request.setAttribute("errorMessage", "Invalid ID or password!");
            request.getRequestDispatcher("studentLogin.jsp").forward(request, response);
        }
    }

    protected void register(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        String name = request.getParameter("stu_name");
        String email = request.getParameter("stu_email");
        String phone = request.getParameter("stu_phone");
        String faculty = request.getParameter("faculty");
        String password = request.getParameter("stu_pass");

        Student student = new Student();
        student.setStu_Name(name);
        student.setStu_Email(email);
        student.setStu_Phone(phone);
        student.setStu_Faculty(faculty);
        student.setPassword(password);

        DAOstudentUser dao = new DAOstudentUser();
        try {
            int newStudentId = dao.registerStudent(student);
            response.sendRedirect("registerStudent.jsp?studentId=" + newStudentId);
        } catch (SQLException e) {
            throw new ServletException("Error registering student", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("register".equalsIgnoreCase(action)) {
            register(request, response);
        } else {
            login(request, response);
        }
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("studentLogin.jsp");
    }

    @Override
    public String getServletInfo() {
        return "Handles student login and registration";
    }
}
