package controller;
import dao.DAOViolation;
import model.Violation;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

@WebServlet("/userViolation")
public class ViolationUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private DAOViolation dao;

    public void init() {
        dao = new DAOViolation();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String vio = request.getParameter("vio_ID");

        try {
            if (vio != null && !vio.isEmpty()) {
                int vio_ID = Integer.parseInt(vio);
                Violation violation = dao.selectViolationById(vio_ID);

                List<Violation> violations = new ArrayList<>();
                if (violation != null) {
                    violations.add(violation);
                }

                request.setAttribute("userViolation", violations);
                RequestDispatcher dispatcher = request.getRequestDispatcher("Violation_displayUser.jsp");
                dispatcher.forward(request, response);

            } else {
                HttpSession session = request.getSession(false);
                List vehPlates = null;

                if (session != null) {
                    vehPlates = (List) session.getAttribute("veh_plate");
                }
                if (vehPlates == null || vehPlates.isEmpty()) {
                    response.sendRedirect("Violation_displayUser.jsp");
                    return;
                }

                List<Violation> violations = new ArrayList<>();
                if (vehPlates != null && !vehPlates.isEmpty()) {
                    for (Object plateObj : vehPlates) {
                        String plate = (String) plateObj;
                        violations.addAll(dao.selectViolationsByPlate(plate));
                    }
                }

                request.setAttribute("userViolation", violations);
                RequestDispatcher dispatcher = request.getRequestDispatcher("Violation_displayUser.jsp");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException("Error retrieving violations", e);
        }
    }
}
