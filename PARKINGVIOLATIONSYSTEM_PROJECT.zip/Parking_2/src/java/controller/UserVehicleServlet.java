package controller;

import dao.DAOVehicle;
import model.Vehicle;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/userVehicle")
public class UserVehicleServlet extends HttpServlet {
    private DAOVehicle dao;

    public void init() throws ServletException {
        dao = new DAOVehicle();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer studentID = (Integer) session.getAttribute("studentID");

        if (studentID == null) {
            response.sendRedirect("studentLogin.jsp");
            return;
        }

        String action = request.getParameter("action");
        if (action == null || action.equals("list")) {
            listUserVehicles(request, response, studentID);
        } else {
            response.sendRedirect("studentDisplay.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer studentID = (Integer) session.getAttribute("studentID");

        if (studentID == null) {
            response.sendRedirect("studentLogin.jsp");
            return;
        }

        String action = request.getParameter("action");

        if ("create".equals(action)) {
            createUserVehicle(request, response, studentID);
        } else if ("delete".equals(action)) {
            deleteUserVehicle(request, response, studentID);
        } else {
            response.sendRedirect("userVehicle?action=list");
        }
    }

    private void listUserVehicles(HttpServletRequest request, HttpServletResponse response, int studentID)
            throws ServletException, IOException {
        List<Vehicle> vehicleList = dao.getVehiclesByStudentId(studentID);
        request.setAttribute("vehicleList", vehicleList);
        RequestDispatcher rd = request.getRequestDispatcher("userV_info.jsp");
        rd.forward(request, response);
    }

    private void createUserVehicle(HttpServletRequest request, HttpServletResponse response, int studentID)
            throws IOException, ServletException {
        String plate = request.getParameter("veh_plate");
        String type = request.getParameter("veh_type");
        String brand = request.getParameter("veh_brand");
        String color = request.getParameter("veh_color");

        Vehicle vehicle = new Vehicle(plate, studentID, type, brand, color);

        try {
            dao.insertVehicle(vehicle);
            response.sendRedirect("userVehicle?action=list");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void deleteUserVehicle(HttpServletRequest request, HttpServletResponse response, int studentID)
            throws IOException, ServletException {
        String plate = request.getParameter("veh_plate");
        boolean success = dao.deleteVehicleByPlateAndStudent(plate, studentID);

        if (success) {
            response.sendRedirect("userVehicle?action=list");
        } else {
            request.setAttribute("error", "Unauthorized or failed deletion.");
            listUserVehicles(request, response, studentID);
        }
    }
}
