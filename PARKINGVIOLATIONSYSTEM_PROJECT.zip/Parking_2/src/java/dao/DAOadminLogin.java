package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Connection.DBConnection;
/**
 *
 * @author Tengku Maria
 */
public class DAOadminLogin {
    public boolean login(int staffID, String staffPassword){
        try{
            Connection conn = DBConnection.createConnection();
            String sql = "SELECT * FROM Staff WHERE Staff_ID = ? AND Staff_Password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, staffID);
            stmt.setString(2, staffPassword);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
    }
}

