package dao;
import Connection.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import model.Staff;
/**
 *
 * @author Tengku Maria
 */
public class StaffDAO {
    public Staff getStaffById(int id) {
    Staff staff = null;
    try (Connection conn = DBConnection.createConnection()) {
        String sql = "SELECT * FROM Staff WHERE Staff_ID = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setInt(1, id);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            staff = new Staff(
                rs.getInt("Staff_ID"),
                rs.getString("Staff_name"),
                rs.getString("Staff_IC"),
                rs.getString("Staff_contact"),
                rs.getString("Staff_password")
            );
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return staff;
}

}
